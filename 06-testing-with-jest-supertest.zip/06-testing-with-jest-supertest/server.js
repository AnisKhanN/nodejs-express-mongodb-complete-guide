const app = require("./src/app");
app.listen(3000, () => {
    console.log("Server is running on port https://localhost:3000");
});
module.exports = app;
